#include <gmp.h>
#include <inttypes.h>
#include <stdio.h>

void printData(mpz_t data[], int64_t length){

  char *s;
  int64_t i;
  for(i=0;i<length;i++){
    s = mpz_get_str(0,10,data[i]);
    if((i+1)%8==0) printf("\n");
    printf("data[%lld]= %s; ",(long long int)i,s);
  }
  printf("\n\n");
}

void printData_int64(int64_t data[], int64_t length){

  int64_t i;
  for(i=0;i<length;i++){
    if((i+1)%8==0) printf("\n");
    printf("data[%lld]= %lld; ",(long long int)i,(long long int)data[i]);
  }
  printf("\n\n");
}

void initialize(mpz_t* vector,int64_t length){
  int64_t i;
  for(i=0;i<length;i++){
    mpz_init(vector[i]);
  }
}

void initialize_matrix(mpz_t **vector, int64_t outerlength, int64_t innerlength){
  int64_t i;
  for(i=0;i<outerlength;i++)
    initialize(vector[i],innerlength);
}
