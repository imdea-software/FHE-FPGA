void from_Q_to_CRT(mpz_t* output_number_CRT,mpz_t number_Q,int num_primes,mpz_t *P);
void from_CRT_to_Q(mpz_t output_number_Q,mpz_t* number_CRT,int num_primes, mpz_t *coeffs,mpz_t Q);
void from_Q_to_CRT_int64(int64_t* output_number_CRT,mpz_t number_Q,int num_primes,int64_t *P);
void from_CRT_to_Q_int64(mpz_t output_number_Q,int64_t* number_CRT,int num_primes, mpz_t *coeffs,mpz_t Q);
void from_Q_to_CRT_parallel(mpz_t* output_number_CRT,mpz_t number_Q,int num_primes,mpz_t *P);
void from_CRT_to_Q_parallel(mpz_t output_number_Q,mpz_t* number_CRT,int num_primes, mpz_t *coeffs,mpz_t Q);
void from_Q_to_CRT_int64_parallel(int64_t* output_number_CRT,mpz_t number_Q,int num_primes,int64_t *P);
void from_CRT_to_Q_int64_parallel(mpz_t output_number_Q,int64_t* number_CRT,int num_primes, mpz_t *coeffs,mpz_t Q);
