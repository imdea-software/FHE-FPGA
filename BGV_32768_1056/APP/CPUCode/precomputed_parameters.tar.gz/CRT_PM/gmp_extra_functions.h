void initialize(mpz_t* vector,int64_t length);
void initialize_matrix(mpz_t **vector, int64_t outerlength, int64_t innerlength);
void printData(mpz_t data[], int64_t length);
void printData_int64(int64_t data[], int64_t length);
