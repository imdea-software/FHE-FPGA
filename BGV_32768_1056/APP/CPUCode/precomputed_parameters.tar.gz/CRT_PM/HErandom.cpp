#include <string>
#include <NTL/ZZ.h>
#include <inttypes.h>
#include <sstream>
#include <stdlib.h>
#include <gmp.h>
#include "HErandom.h"


using namespace NTL;

//extern "C" const char* zToString(const ZZ &z);
//extern "C" const char* strRandomBnd_toString(char* bnd);

const char* zToString(const ZZ &z) {
    std::stringstream buffer;
    buffer << z;
    return buffer.str().c_str();
}
const void fromGMPtoZZ(ZZ* output, mpz_t input,size_t* countp){
  size_t count=(*countp);
  unsigned char s[*countp];
  for(unsigned int i=0;i<count;i++)
    s[i]=0;
  mpz_export(s,&count,-1,sizeof(char),0,0,input);
  ZZFromBytes(*output,s,count);

}
const void fromZZtoGMP(mpz_t* outputp,ZZ input,size_t* countp){
  //  mpz_t output = (*outputp);
  size_t count = *countp;
  unsigned char s[count];//256/4 number of bytes
  BytesFromZZ(s,input,count);
  mpz_import(*outputp,count,-1,sizeof(char),0,0,s);
}

const void mpz_RandomBnd(mpz_t* outputp, mpz_t bnd,size_t* countp){
  ZZ bnd_zz;
  fromGMPtoZZ(&bnd_zz,bnd,countp);
  fromZZtoGMP(outputp,RandomBnd(bnd_zz),countp);
}
const char* strRandomBnd_toString(char* bnd){
  ZZ q_zz (INIT_VAL,bnd);
  return zToString(RandomBnd(q_zz));
}

const int64_t wrapRandomBnd(double number){
  return RandomBnd(number);
}
