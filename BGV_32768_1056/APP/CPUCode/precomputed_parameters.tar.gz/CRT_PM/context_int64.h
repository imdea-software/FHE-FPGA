void import_values_int64();

typedef struct Context_int64{
  int num_primes;
  mpz_t Q;
  int64_t *P;
  int64_t * handy_prime;
  int64_t * gen;
  int64_t ** phi_powers;
  int64_t ** iphi_powers;
  int64_t *** W_values;
  int64_t *** iW_values;
  int64_t * iN;
  mpz_t *euclidean_coeffs;
  int64_t N;
  int n;
}Context_int64;

void get_parameters_int64(Context_int64* context);

int CRTmultiply_int64(mpz_t *resultVector,
		mpz_t *data1,
		mpz_t *data2);
int multiply_int64(int64_t N,int64_t n,int64_t *resultVector,int64_t *data1,int64_t *data2,int64_t *phi_powers,int64_t *iphi_powers, int64_t **W_values,int64_t **iW_values, int64_t P,int64_t iN);

int CRTmultiply_int64_parallel(mpz_t *resultVector,
		mpz_t *data1,
		mpz_t *data2);
int multiply_int64_parallel(int64_t N,int64_t n,int64_t *resultVector,int64_t *data1,int64_t *data2,int64_t *phi_powers,int64_t *iphi_powers, int64_t **W_values,int64_t **iW_values, int64_t P,int64_t iN);

int multiply_scalar_int64(int64_t N,int64_t resultVector[],int64_t data1[],int64_t data2);
int sum_int64(int64_t N,int64_t resultVector[N],int64_t data1[N],int64_t data2[N]);
int sub_int64(int64_t N,int64_t resultVector[],int64_t data1[],int64_t data2[]);
int sum_scalar_int64(int64_t N,int64_t resultVector[],int64_t data1[],int64_t data2);


int multiply_CRT_values_int64(int num_primes,int64_t N,int n,
		 int64_t **resultVector,
		 int64_t **data1,
		 int64_t **data2,
		 int64_t **phip,
		 int64_t **iphip,
		 int64_t ***Wp,
		 int64_t ***iWp,
		 int64_t *P,
		 int64_t *iN);


int multiply_CRT_values_int64_parallel(int num_primes,int64_t N,int n,
		 int64_t **resultVector,
		 int64_t **data1,
		 int64_t **data2,
		 int64_t **phip,
		 int64_t **iphip,
		 int64_t ***Wp,
		 int64_t ***iWp,
		 int64_t *P,
		 int64_t *iN);

int sum_scalar_CRT_int64(int64_t **resultVector,int64_t **data1,int64_t *data2);
int sum_scalar_CRT_values_int64(int num_primes, int64_t N,int64_t **resultVector,int64_t **data1,int64_t *data2);
int multiply_scalar_CRT_int64(int64_t **resultVector,int64_t **data1,int64_t *data2);
int multiply_scalar_CRT_values_int64(int num_primes, int64_t N,int64_t **resultVector,int64_t **data1,int64_t *data2);
int sum_CRT_values_int64(int num_primes, int64_t N, int64_t **resultVector,int64_t **data1,int64_t **data2);
int sum_CRT_int64(int64_t **resultVector, int64_t **data1, int64_t **data2);
int sub_CRT_values_int64(int num_primes, int64_t N,int64_t **resultVector,int64_t **data1,int64_t **data2);
int sub_CRT_int64(int64_t **resultVector,int64_t **data1,int64_t **data2);
