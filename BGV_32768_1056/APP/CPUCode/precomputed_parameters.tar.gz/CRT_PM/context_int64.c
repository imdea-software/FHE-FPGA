#include <string.h>
#include <stdint.h>
#include <math.h>
#include <stdio.h>
#include <time.h>
#include <sys/time.h>
#include <inttypes.h>
#include <stdlib.h>
#include <gmp.h>
#include "context.h"
#include <omp.h>
#include "gmp_extra_functions.h"
#include "context_int64.h"
#include "bijection_CRT_Q.h"

void read_array_pointer_int64(int64_t **data, long long length,long long inner_length,const  char * name, int base);

void bitReversal_int64(int64_t x[], int64_t N);
void mulByiN_int64(int64_t length,int64_t outputVector[length], int64_t m,int64_t iN);
void mulByPhi_int64(int64_t N,int64_t dataIn1[N], int64_t PhiPowers[N],int64_t P);
void mulByiPhi_int64(int64_t N,int64_t dataIn1[N], int64_t PhiPowers[N],int64_t P);

int multiply_CRT_int64_parallel(int64_t **resultVector,
		 int64_t **data1,
		 int64_t **data2);

int multiply_CRT_int64(int64_t **resultVector,
		 int64_t **data1,
		 int64_t **data2);

int imported_values_int64=0; //false

// Same values and implementation of the FFT for FPGA's but with everything in C. For more information about parameters check the Maxeler project.

// IMPORTANT!! iN and P are set manually at the beginning of main()
//#define iN 1044991
//#define P 1049089
//Wpowers are the powers of the nth primitive root of unity modulus P
int num_primes;

int64_t *P,
  * handy_prime,
  * gen,** phi_powers,
  ** iphi_powers,
  *** W_values,
  *** iW_values,
  * iN;

mpz_t *euclidean_coeffs;
mpz_t Q;
int64_t N;
int n;

struct timeval tvalBefore, tvalAfter;
int64_t **CRT_resultVector;
int64_t **CRT_data1;
int64_t **CRT_data2;
int64_t *aux;

//only for Polynomial Multiplication using FFT-IFFT parameters
void import_precomputed_parameters_int64(){
  //initialize data
  P=malloc(sizeof(int64_t)*num_primes);
  iN=malloc(sizeof(int64_t)*num_primes);
  phi_powers=(int64_t**)malloc(sizeof(int64_t*)*num_primes);
  iphi_powers=(int64_t**)malloc(sizeof(int64_t*)*num_primes);
  W_values=(int64_t***)malloc(sizeof(int64_t**)*num_primes);
  iW_values=(int64_t***)malloc(sizeof(int64_t**)*num_primes);

  int64_t i,j;
  for(i=0;i<num_primes;i++){
    phi_powers[i]=malloc(sizeof(int64_t)*N);
    iphi_powers[i]=malloc(sizeof(int64_t)*N);
    W_values[i]=(int64_t**)malloc(sizeof(int64_t*)*n);
    iW_values[i]=(int64_t**)malloc(sizeof(int64_t*)*n);
    for(j=0;j<n;j++){
      W_values[i][j]=malloc(sizeof(int64_t)*N/2);
      iW_values[i][j]=malloc(sizeof(int64_t)*N/2);;
    }
  }

  read_array_int64(P,num_primes,"data/primes.dat",16);
  read_array_int64(iN,num_primes,"data/iN.dat",16);
  char *dir= malloc(sizeof("data/data_/"));
  char *filename = malloc(sizeof("data/data_/filenameveryveryveryverylong.dat"));

  for(i=0;i<num_primes;i++){
    strcpy(dir,"data/data");
    char i_str[2];
    sprintf(i_str, "%i", (int)i);
    strcat(dir,i_str);
    strcat(dir,"/");


    //printing phi_powers
    strcpy(filename,dir);
    strcat(filename,"phi_powers.dat");
    read_array_int64(phi_powers[i],N,filename,16);
    //printing iphi_powers
    strcpy(filename,dir);
    strcat(filename,"iphi_powers.dat");
    read_array_int64(iphi_powers[i],N,filename,16);

    //printing W_values
    strcpy(filename,dir);
    strcat(filename,"W_values.dat");
    read_array_pointer_int64(W_values[i],n,N/2,filename,16);
    //printing iW_values
    strcpy(filename,dir);
    strcat(filename,"iW_values.dat");
    read_array_pointer_int64(iW_values[i],n,N/2,filename,16);
  }
}

void import_values_int64(){
  //read number of primes
  read_array_int(&num_primes,1,"data/num_primes.dat");
  //read n and N
  int64_t nN[2];
  read_array_int64(nN,2,"data/n_N.dat",10);
  n=nN[0];
  N=nN[1];
  import_precomputed_parameters_int64();
  mpz_init(Q);
  read_array(&Q,1,"data/Q.dat");
  //primes_minus_bit no necessary for C code
  //read_array(...,"data/primes_minus_bit.dat")
  //read_array(...,"data/bitsize_primes_minus_bit.dat")
  //read_array(...,"data/bitsize_primes.dat")
  euclidean_coeffs=malloc(sizeof(mpz_t)*num_primes);
  initialize(euclidean_coeffs,num_primes);
  read_array(euclidean_coeffs,num_primes,"data/coefficients_extended_euclidean.dat");

  long long i;
  CRT_resultVector=malloc(sizeof(int64_t*)*num_primes);
  for(i=0;i<num_primes;i++){
    CRT_resultVector[i]=malloc(sizeof(int64_t)*N);
  }

  CRT_data1=malloc(sizeof(int64_t*)*num_primes);
  for(i=0;i<num_primes;i++){
    CRT_data1[i]=malloc(sizeof(int64_t)*N);
  }

  CRT_data2=malloc(sizeof(int64_t*)*num_primes);
  for(i=0;i<num_primes;i++){
    CRT_data2[i]=malloc(sizeof(int64_t)*N);
  }

  aux=malloc(sizeof(int64_t)*num_primes);
  
  imported_values_int64=1;
}

void FFT_int64(int64_t N,int n,int64_t  output[N],int64_t data[N], int64_t **W, int64_t P){
  int64_t j,i;
  int64_t numTicks = N/2;
  int64_t  *pTmp;
  int64_t aux[N];
  int64_t  *pAux=aux;
  int64_t *pOutput=output;

  if(output!=data){
    for(i=0;i<N;i++){
      output[i]=data[i];
    }
  }

  for(i=0;i<n;i++){
    for(j=0; j<numTicks; j++){
      pAux[j]=(output[2*j]+output[2*j+1]*W[i][j])%P;
      pAux[j+N/2]=(output[2*j]-output[2*j+1]*W[i][j])%P;
    }
    if(i<n-1){
      pTmp = output;
      output = pAux;
      pAux = pTmp;
    }
  }

  if(n%2!=0){
    for(i = 0;i<N;i++){
      int64_t aux = pAux[i];
      pAux[i]=pOutput[i];
      pOutput[i]=aux;
    }
  }else{
  }
}

void IFFT_int64(int64_t N,int n,int64_t output[N],int64_t data[N],int64_t **iWp, int64_t P,int64_t iN){
  FFT_int64(N,n,output,data,iWp,P);
  mulByiN_int64(N,output,P,iN);
}

int multiply_int64(int64_t N,int64_t n,int64_t *resultVector,int64_t *data1,int64_t *data2,int64_t *phi_powers,int64_t *iphi_powers, int64_t **W_values,int64_t **iW_values, int64_t P,int64_t iN)
{

  int64_t dataFFT1[N],dataFFT2[N];
  int64_t i;
  for(i=0;i<N;i++){
    dataFFT1[i]=data1[i];
    dataFFT2[i]=data2[i];
  }

  /* printf("multiplying:\n"); */
  /*   printf("dataFFT1:\n"); */
    //printData(dataFFT1,N);
  /* printf("dataFFT2:\n"); */
  //printData(dataFFT2,N);
  //----------------------------------------------------------
  //  Polynomial multiplication using FFT over Z_p[x]/<x^n+1>
  //----------------------------------------------------------

  //first step of algorithm (multiplication of a[] and b[] by phi[])

  mulByPhi_int64(N,dataFFT1,phi_powers,P);
  mulByPhi_int64(N,dataFFT2,phi_powers,P);

  //FFT(dataIn1) starts
  bitReversal_int64(dataFFT1,N);
  FFT_int64(N,n,dataFFT1,dataFFT1,W_values,P);

  //printData(dataFFT1,N);

  //  for(i=0;i<N;i++){
  //    mpz_init_set(resultVector[i],dataFFT1[i]);
  //  }


  //FFT(dataIn1) ==> dataFFT1;

  //OBSERVATION: BOTH FFTs COULD BE EXECUTED CONCURRENTLY SINCE THEY DON'T DEPEND ON EACH OTHER

  //FFT(dataIn2) starts
  bitReversal_int64(dataFFT2,N);

  FFT_int64(N,n,dataFFT2,dataFFT2,W_values,P);

  //  printData(dataFFT2,N);


  //FFT(dataIn2) ==> dataFFT2;
  //FFT finished


  //FFT(dataIn1)*FFT(dataIn2)
  for(i=0;i<N;i++){
    resultVector[i]=(dataFFT1[i]*dataFFT2[i])%P;
  }

  //printf("after mod:\n");
  //iFFT(actualDataOut) starts
  bitReversal_int64(resultVector,N);
  IFFT_int64(N,n,resultVector,resultVector,iW_values,P,iN);
  //iFFT finished

  mulByiPhi_int64(N,resultVector,iphi_powers,P);
  for(i=0;i<N;i++){
    if(resultVector[i]<0)
      resultVector[i]+=P;
  }
  //printf("result:\n");
  //printData(resultVector,N);
  return 0;
}


int multiply_CRT_values_int64(int num_primes,int64_t N,int n,
		 int64_t **resultVector,
		 int64_t **data1,
		 int64_t **data2,
		 int64_t **phip,
		 int64_t **iphip,
		 int64_t ***Wp,
		 int64_t ***iWp,
		 int64_t *P,
		 int64_t *iN){

  int i;
  for(i=0;i<num_primes;i++){
    //printf("iter:%i\n",i);
    //printf("data:\n");
    //printData(data1[i],N);
    multiply_int64(N,n,resultVector[i],data1[i],data2[i],phip[i],iphip[i],Wp[i],iWp[i],P[i],iN[i]);
    //printf("finished iter:%i\n",i);
  }

  return 0;
}

int multiply_CRT_values_int64_parallel(int num_primes,int64_t N,int n,
		 int64_t **resultVector,
		 int64_t **data1,
		 int64_t **data2,
		 int64_t **phip,
		 int64_t **iphip,
		 int64_t ***Wp,
		 int64_t ***iWp,
		 int64_t *P,
		 int64_t *iN){

  int i;

  #pragma omp parallel for

  for(i=0;i<num_primes;i++){
    //printf("iter:%i\n",i);
    //printf("data:\n");
    //printData(data1[i],N);
    multiply_int64(N,n,resultVector[i],data1[i],data2[i],phip[i],iphip[i],Wp[i],iWp[i],P[i],iN[i]);
    //printf("finished iter:%i\n",i);
  }

  return 0;
}


int CRTmultiply_int64(mpz_t *resultVector,
		mpz_t *data1,
		mpz_t *data2){

  if(!imported_values_int64){
    //import_values();
    exit(1);//1 means that the values have not been imported;
  }
  long long i,j;

  //  gettimeofday (&tvalBefore, NULL);
  for(i=0;i<N;i++){
    from_Q_to_CRT_int64(aux,data1[i],num_primes,P);

    for(j=0;j<num_primes;j++)
      CRT_data1[j][i]=aux[j];
  }

  for(i=0;i<N;i++){
    from_Q_to_CRT_int64(aux,data2[i],num_primes,P);

    for(j=0;j<num_primes;j++)
      CRT_data2[j][i]=aux[j];
  }

  for(i=0;i<num_primes;i++){
    multiply_int64(N,n,CRT_resultVector[i],CRT_data1[i],CRT_data2[i],phi_powers[i],iphi_powers[i],W_values[i],iW_values[i],P[i],iN[i]);
  }

  for(i=0;i<N;i++){

    for(j=0;j<num_primes;j++)
      aux[j]=CRT_resultVector[j][i];

    from_CRT_to_Q_int64(resultVector[i],aux,num_primes,euclidean_coeffs,Q);

  }

  //  gettimeofday (&tvalAfter, NULL);
  /* printf("Time in microseconds: %ld microseconds\n", */
  /* 	 ((tvalAfter.tv_sec - tvalBefore.tv_sec)*1000000L */
  /* 	  +tvalAfter.tv_usec) - tvalBefore.tv_usec */
  /* 	 ); */

  return 0;
}


int CRTmultiply_int64_generic(mpz_t *resultVector,
		mpz_t *data1,
		mpz_t *data2,
		mpz_t _Q){

  struct timeval tvalBefore, tvalAfter;
  int64_t **CRT_resultVector;
  int64_t **CRT_data1;
  int64_t **CRT_data2;

  long long i,j;

  CRT_resultVector=malloc(sizeof(int64_t*)*num_primes);
  for(i=0;i<num_primes;i++){
    CRT_resultVector[i]=malloc(sizeof(int64_t)*N);
  }

  CRT_data1=malloc(sizeof(int64_t*)*num_primes);
  for(i=0;i<num_primes;i++){
    CRT_data1[i]=malloc(sizeof(int64_t)*N);
  }

  CRT_data2=malloc(sizeof(int64_t*)*num_primes);
  for(i=0;i<num_primes;i++){
    CRT_data2[i]=malloc(sizeof(int64_t)*N);
  }

  int64_t aux[num_primes];

  gettimeofday (&tvalBefore, NULL);
  for(i=0;i<N;i++){
    from_Q_to_CRT_int64(aux,data1[i],num_primes,P);

    for(j=0;j<num_primes;j++)
      CRT_data1[j][i]=aux[j];
  }

  for(i=0;i<N;i++){
    from_Q_to_CRT_int64(aux,data2[i],num_primes,P);

    for(j=0;j<num_primes;j++)
      CRT_data2[j][i]=aux[j];
  }

  for(i=0;i<num_primes;i++){
    multiply_int64(N,n,CRT_resultVector[i],CRT_data1[i],CRT_data2[i],phi_powers[i],iphi_powers[i],W_values[i],iW_values[i],P[i],iN[i]);
  }

  for(i=0;i<N;i++){

    for(j=0;j<num_primes;j++)
      aux[j]=CRT_resultVector[j][i];

    from_CRT_to_Q_int64(resultVector[i],aux,num_primes,euclidean_coeffs,Q);

  }


  for(i=0;i<N;i++){
      mpz_mmod(resultVector[i],resultVector[i],_Q);
  }
  
  gettimeofday (&tvalAfter, NULL);
  printf("Time in microseconds: %ld microseconds\n",
	 ((tvalAfter.tv_sec - tvalBefore.tv_sec)*1000000L
	  +tvalAfter.tv_usec) - tvalBefore.tv_usec
	 );

  return 0;
}

int CRTmultiply_int64_parallel(mpz_t *resultVector,
		mpz_t *data1,
		mpz_t *data2){

  struct timeval tvalBefore, tvalAfter;
  int64_t **CRT_resultVector;
  int64_t **CRT_data1;
  int64_t **CRT_data2;

  long long i,j;

  CRT_resultVector=malloc(sizeof(int64_t*)*num_primes);
  for(i=0;i<num_primes;i++){
    CRT_resultVector[i]=malloc(sizeof(int64_t)*N);
  }

  CRT_data1=malloc(sizeof(int64_t*)*num_primes);
  for(i=0;i<num_primes;i++){
    CRT_data1[i]=malloc(sizeof(int64_t)*N);
  }

  CRT_data2=malloc(sizeof(int64_t*)*num_primes);
  for(i=0;i<num_primes;i++){
    CRT_data2[i]=malloc(sizeof(int64_t)*N);
  }

 int num_threads =  strtol(getenv("OMP_NUM_THREADS"),NULL,10);
  int64_t **aux = malloc(sizeof(int64_t*)*num_threads);
  for(i=0;i<num_threads;i++){
    aux[i]=malloc(sizeof(int64_t)*num_primes);
  }

  gettimeofday (&tvalBefore, NULL);
  #pragma omp parallel for private(j)
  for(i=0;i<N;i++){
    from_Q_to_CRT_int64(aux[omp_get_thread_num()],data1[i],num_primes,P);

    for(j=0;j<num_primes;j++)
      CRT_data1[j][i]=aux[omp_get_thread_num()][j];
  }

  #pragma omp parallel for private(j)
  for(i=0;i<N;i++){
    from_Q_to_CRT_int64(aux[omp_get_thread_num()],data2[i],num_primes,P);

    for(j=0;j<num_primes;j++)
      CRT_data2[j][i]=aux[omp_get_thread_num()][j];
  }

  /* for(i=0;i<num_primes;i++){ */
  /*   multiply_int64(N,n,CRT_resultVector[i],CRT_data1[i],CRT_data2[i],phi_powers[i],iphi_powers[i],W_values[i],iW_values[i],P[i],iN[i]); */
  /* } */

  multiply_CRT_int64_parallel(CRT_resultVector,CRT_data1,CRT_data2);
 
  #pragma omp parallel for private(j)
  for(i=0;i<N;i++){

    for(j=0;j<num_primes;j++)
      aux[omp_get_thread_num()][j]=CRT_resultVector[j][i];

    from_CRT_to_Q_int64(resultVector[i],aux[omp_get_thread_num()],num_primes,euclidean_coeffs,Q);

  }

  gettimeofday (&tvalAfter, NULL);
  printf("Time in microseconds: %ld microseconds\n",
	 ((tvalAfter.tv_sec - tvalBefore.tv_sec)*1000000L
	  +tvalAfter.tv_usec) - tvalBefore.tv_usec
	 );

  return 0;
}


int multiply_CRT_int64(int64_t **resultVector,
		 int64_t **data1,
		 int64_t **data2){

  if(!imported_values_int64){
    //import_values();
    exit(1);//1 means that the values have not been imported;
  }

  return multiply_CRT_values_int64(num_primes,N,n,resultVector,data1,data2,phi_powers,iphi_powers,W_values,iW_values,P,iN);
}

int multiply_CRT_int64_parallel(int64_t **resultVector,
		 int64_t **data1,
		 int64_t **data2){

  if(!imported_values_int64){
    //import_values();
    exit(1);//1 means that the values have not been imported;
  }

  return multiply_CRT_values_int64_parallel(num_primes,N,n,resultVector,data1,data2,phi_powers,iphi_powers,W_values,iW_values,P,iN);
}

void mulByPhi_int64(int64_t N,int64_t dataIn1[N], int64_t *PhiPowers,int64_t P){
  int64_t i;
  for(i=0;i<N;i++){
    dataIn1[i]=(dataIn1[i]*PhiPowers[i])%P;
  }
}
void mulByiPhi_int64(int64_t N,int64_t dataFinal[N],int64_t *iPhiPowers,int64_t P){
  mulByPhi_int64(N,dataFinal,iPhiPowers,P);
}

void mulByiN_int64(int64_t length,int64_t outputVector[length], int64_t P,int64_t iN){
  int64_t i;
  for(i=0;i<length;i++){
    outputVector[i]=(outputVector[i]*iN)%P;
  }
}


void bitReversal_int64(int64_t x[], int64_t N){
	/* Do the bit reversal */
	    int64_t i2 = N >> 1;
	    int64_t tx;
	    int64_t k;
	    int64_t j = 0;
	    int64_t i;
	    for (i=0;i<N-1;i++) {
	        if (i < j) {
	            tx = x[i];
	            x[i] = x[j];
	            x[j] = tx;
	        }
	       k = i2;
	        while (k <= j) {
	            j -= k;
	            k >>= 1;
	        }
	        j += k;
	    }

}

int sum_int64(int64_t N,int64_t *resultVector,int64_t *data1,int64_t *data2){
  int64_t i;
  for(i=0;i<N;i++){
    resultVector[i]=data1[i]+data2[i];
    //mpz_mmod(resultVector[i],resultVector[i],P);
  }
  return 0;
}

int sum_CRT_int64(int64_t **resultVector, int64_t **data1, int64_t **data2){

  if(!imported_values_int64){
    //import_values();
    exit(1);//1 means that the values have not been imported;
  }

  return sum_CRT_values_int64(num_primes,N,resultVector,data1,data2);
}
int sum_CRT_values_int64(int num_primes, int64_t N, int64_t **resultVector,int64_t **data1,int64_t **data2){
  int64_t i;
  for (i=0;i<num_primes;i++){
    sum_int64(N,resultVector[i],data1[i],data2[i]);
  }

  return 0;
}



int sub_int64(int64_t N,int64_t resultVector[],int64_t data1[],int64_t data2[]){
  int64_t i;
  for(i=0;i<N;i++){
    resultVector[i]=data1[i]-data2[i];
    //mpz_mmod(resultVector[i],resultVector[i],P);
  }
  return 0;
}

int sub_CRT_int64(int64_t **resultVector,int64_t **data1,int64_t **data2){
  if(!imported_values_int64){
    //import_values();
    exit(1);//1 means that the values have not been imported;
  }

  return sub_CRT_values_int64(num_primes,N,resultVector,data1,data2);
}

int sub_CRT_values_int64(int num_primes, int64_t N,int64_t **resultVector,int64_t **data1,int64_t **data2){
  int64_t i;
  for (i=0;i<num_primes;i++){
    sub_int64(N,resultVector[i],data1[i],data2[i]);
  }
  return 0;
}

int sum_scalar_int64(int64_t N,int64_t resultVector[],int64_t data1[],int64_t data2){
  int64_t i;
  for(i=0;i<N;i++){
    resultVector[i]=data1[i]+data2;
  }
  return 0;
}

int sum_scalar_CRT_int64(int64_t **resultVector,int64_t **data1,int64_t *data2){


  if(!imported_values_int64){
    //import_values();
    exit(1);//1 means that the values have not been imported;
  }

  return sum_scalar_CRT_values_int64(num_primes,N,resultVector,data1,data2);

}

int sum_scalar_CRT_values_int64(int num_primes, int64_t N,int64_t **resultVector,int64_t **data1,int64_t *data2){
  int64_t i;
  for (i=0;i<num_primes;i++){
    sum_scalar_int64(N,resultVector[i],data1[i],data2[i]);
  }
  return 0;
}

int multiply_scalar_int64(int64_t N,int64_t resultVector[],int64_t data1[],int64_t data2){
  int64_t i;
  for(i=0;i<N;i++){
    resultVector[i]=data1[i]*data2;
    //mpz_mmod(resultVector[i],resultVector[i],P);
  }
  return 0;
}

int multiply_scalar_CRT_values_int64(int num_primes, int64_t N,int64_t **resultVector,int64_t **data1,int64_t *data2){
  int64_t i;
  for (i=0;i<num_primes;i++){
    multiply_scalar_int64(N,resultVector[i],data1[i],data2[i]);
  }
  return 0;
}

int multiply_scalar_CRT_int64(int64_t **resultVector,int64_t **data1,int64_t *data2){

  if(!imported_values_int64){
    //import_values();
    exit(1);//1 means that the values have not been imported;
  }

  return multiply_scalar_CRT_values_int64(num_primes,N,resultVector,data1,data2);

}

void read_array_pointer_int64(int64_t **data, long long length,long long inner_length,const  char * name,int base){
  FILE *file = fopen(name,"r");
  char s[1024]; //it takes numbers in hex base for upto 16384 bits
  if(file==NULL){
    fprintf(stderr,"could not open file %s\n",name);
    exit(-1);}
  long long i,j;
  for(i=0;i<length;i++){
    for(j=0;j<inner_length;j++){
    fscanf(file, "%s",s);
    data[i][j]=(int64_t)strtoull(s,NULL,base);
    }
  }
  fclose(file);
}

void get_parameters_int64(Context_int64* context){
  context->W_values=W_values;
  context->P=P;
  context->handy_prime=handy_prime;
  context->gen=gen;
  context->phi_powers=phi_powers;
  context->iphi_powers=iphi_powers;
  context->W_values=W_values;
  context->iW_values=iW_values;
  context->iN=iN;
  context->euclidean_coeffs=euclidean_coeffs;
  context->N=N;
  context->n=n;
  context->num_primes=num_primes;
  mpz_init_set(context->Q,Q);
}

/* void test(){ */
/*   mpz_t **data1_CRT; */
/*   mpz_t **data2_CRT; */
/*   mpz_t **data3_CRT; */

/*   data1_CRT=malloc(sizeof(mpz_t*)*num_primes); */
/*   data2_CRT=malloc(sizeof(mpz_t*)*num_primes); */
/*   data3_CRT=malloc(sizeof(mpz_t*)*num_primes); */

/*   int i; */
/*   int64_t j; */
/*   for(i=0;i<num_primes;i++){ */
/*     data1_CRT[i]=malloc(sizeof(mpz_t)*N); */
/*     data2_CRT[i]=malloc(sizeof(mpz_t)*N); */
/*     data3_CRT[i]=malloc(sizeof(mpz_t)*N); */
/*     for(j=0;j<N;j++){ */
/*       mpz_init_set_ui(data1_CRT[i][j],1); */
/*       mpz_init_set_ui(data2_CRT[i][j],0); */
/*       mpz_init_set_ui(data3_CRT[i][j],0); */
/*     } */
/*     mpz_set_ui(data2_CRT[i][N/2],1); */
/*   } */

/*   printf("data1_CRT:\n"); */
/*   //printData((mpz_t*)data1_CRT,num_primes*N); */
/*   printf("data2_CRT:\n"); */
/*   //  printData((mpz_t*)data2_CRT,num_primes*N); */

/*   multiply_CRT((mpz_t **)data3_CRT,(mpz_t**)data1_CRT,(mpz_t**)data2_CRT); */


/*   printf("result:\n"); */

/*   mpz_t output[N]; */
/*   initialize(output,N); */
/*   mpz_t CRT_vals[num_primes]; */
/*   mpz_init(Q); */
/*   read_array(&Q,1,"data/Q.dat"); */
/*   initialize(CRT_vals,num_primes); */

/*   for(j=0;j<N;j++){ */
/*     for(i=0;i<num_primes;i++){ */
/*       mpz_set(CRT_vals[i],data3_CRT[i][j]); */
/*     } */
/*     from_CRT_to_Q(output[j],CRT_vals,num_primes,euclidean_coeffs,Q); */
/*   } */
/*   printf("resultVector:\n"); */
/*   printData(output,N); */
/*   printf("\nQ=%s\n",mpz_get_str(NULL,16,Q)); */
/* } */

/* void get_parameters(Context* context){ */
/*   context->W_values=W_values; */
/*   context->P=P; */
/*   context->handy_prime=handy_prime; */
/*   context->gen=gen; */
/*   context->phi_powers=phi_powers; */
/*   context->iphi_powers=iphi_powers; */
/*   context->W_values=W_values; */
/*   context->iW_values=iW_values; */
/*   context->iN=iN; */
/*   context->euclidean_coeffs=euclidean_coeffs; */
/*   context->N=N; */
/*   context->n=n; */
/*   context->num_primes=num_primes; */
/*   mpz_init_set(context->Q,Q); */

/* } */

/* DEPRECATED

  mpz_t *PhiPowers;
  mpz_t *iPhiPowers;
  mpz_t **W;
  mpz_t **iW;

  void printData(mpz_t data[], int64_t length){

    char *s;
    for(int64_t i=0;i<length;i++){
      s = mpz_get_str(0,10,data[i]);
      if((i+1)%8==0) printf("\n");
      printf("data[%d]= %s; ",
	     i,s);
    }
    printf("\n\n");
  }
void fillData(mpz_t dataIn[],mpz_t dataIn2[], int64_t length){
  mpz_t val1,val2;
  gmp_randstate_t state,state2;
  gmp_randinit_default(state);
  gmp_randinit_default(state2);
  mpz_init(val1);
  mpz_init(val2);

  for(int64_t i=0; i < length; i++){
    mpz_urandomm(val1,state,P);
    //mpz_init_set(dataIn[i],val1);
    mpz_init_set_ui(dataIn[i],i);//rand()%Poly_Mul_FFT_P;
    mpz_urandomm(val2,state2,P);
    //mpz_init_set(dataIn2[i],val2);
    mpz_init_set_ui(dataIn2[i],0);
  }
  mpz_set_ui(dataIn2[length/2],1);

}

mpz_t resultVector[N];
mpz_t dataFFT1[N];
mpz_t dataFFT2[N];
int main()
{
  //case 8192 with 85 bits minimum
  //mpz_init_set_str(P,"633825300114114700748356599809",10);
  //mpz_init_set_str(iN,"633747928861659364481175403935",10);
  //case 8192 with 20 bits minimum
  //mpz_init_set_str(P,"17185325057",10);
  //mpz_init_set_str(iN,"17183227239",10);
  //case 256 with 20 bits minimum
  //mpz_init_set_str(P,"536874497",10);
  //mpz_init_set_str(iN,"534777331",10);
  //case 1024 with 20 bits minimum
  mpz_init_set_str(P,"2147756033",10);
  mpz_init_set_str(iN,"2145658615",10);
  //case 1024 with prec_params_int64_t
  //mpz_init_set_str(P,"1054721",10);
  //mpz_init_set_str(iN,"1053691",10);

  //case 2048 with 20 bits minimum
  //mpz_init_set_str(P,"4295200769",10);
  //mpz_init_set_str(iN,"4293103503",10);
  //case 4096 with 20 bits minimum
  //mpz_init_set_str(P,"8591712257",10);
  //mpz_init_set_str(iN,"8589614671",10);
  char *prueba;
  prueba = mpz_get_str(0,10,P);
  printf("P : %s\n",prueba);
  prueba = mpz_get_str(0,10,iN);
  printf("iN : %s\n",prueba);
  W = (mpz_t **)malloc(sizeof(mpz_t*)*n);
  iW = (mpz_t **)malloc(sizeof(mpz_t*)*n);
  getValues();

  //printPrecomputedData();

  fillData(dataFFT1,dataFFT2,N);
  struct timeval tvalBefore, tvalAfter;  // removed comma



  //----------------------------------------------------------
  //  Polynomial multiplication using FFT over Z_p[x]/<x^n+1>
  //----------------------------------------------------------


  printf("dataIn1 and dataIn2\n\n");
  printData(dataFFT1,N);
  printf("-------------------------------------------------------------------------------------------------------------------------------------------------\n\n");
  printData(dataFFT2,N);

  gettimeofday (&tvalBefore, NULL);
  //first step of algorithm (multiplication of a[] and b[] by phi[])
  mulByPhi(dataFFT1,dataFFT2);



  //FFT(dataIn1) starts
  bitReversal(dataFFT1,N);


  Poly_Mul_FFT(N/2,dataFFT1);



  //FFT(dataIn1) ==> dataFFT1;

  //OBSERVATION: BOTH FFTs COULD BE EXECUTED CONCURRENTLY SINCE THEY DON'T DEPEND ON EACH OTHER

  //FFT(dataIn2) starts
  bitReversal(dataFFT2,N);

  Poly_Mul_FFT(N/2,dataFFT2);

  //  printData(dataFFT2,N);


  //FFT(dataIn2) ==> dataFFT2;
  //FFT finished


  //FFT(dataIn1)*FFT(dataIn2)
  for(int64_t i=0;i<N;i++){
    mpz_init(resultVector[i]);
    mpz_mul(resultVector[i],(dataFFT1[i]),(dataFFT2[i]));
    mpz_mmod(resultVector[i],resultVector[i],P);
  }
  //iFFT(actualDataOut) starts
  bitReversal(resultVector,N);

  Poly_Mul_IFFT(N/2,resultVector);

  //iFFT finished

  mulByiPhi(resultVector);

  gettimeofday (&tvalAfter, NULL);

  //algorithm finished


  printf("dataIn1*dataIn2 = \n");
  printData(resultVector,N);
  printf("Time in microseconds: %ld microseconds\n",
	 ((tvalAfter.tv_sec - tvalBefore.tv_sec)*1000000L
	  +tvalAfter.tv_usec) - tvalBefore.tv_usec
	 );

}
*/
