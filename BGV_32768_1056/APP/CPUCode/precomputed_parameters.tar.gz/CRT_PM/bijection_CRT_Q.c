#include <gmp.h>
#include <inttypes.h>
#include "gmp_extra_functions.h"
unsigned long long mpz2ull(mpz_t z)
{
    unsigned long long result = 0;
    mpz_export(&result, 0, -1, sizeof result, 0, 0, z);
    return result;
}

void ull2mpz(mpz_t z, unsigned long long ull)
{
    mpz_import(z, 1, -1, sizeof ull, 0, 0, &ull);
}

void from_CRT_to_Q_parallel(mpz_t output_number_Q,mpz_t* number_CRT,int num_primes, mpz_t *coeffs,mpz_t Q){

  int i;
  mpz_set_ui(output_number_Q,0);
  //mpz_t aux;
  mpz_t aux[num_primes];

  initialize(aux,num_primes);

  #pragma omp parallel for
  for(i=0;i<num_primes;i++){
    mpz_mul(aux[i],coeffs[i],number_CRT[i]);
  }

  mpz_set(output_number_Q,aux[0]);
  for(i=1;i<num_primes;i++){
    mpz_add(output_number_Q,output_number_Q,aux[i]);
  }

  mpz_mmod(output_number_Q,output_number_Q,Q);
}

void from_CRT_to_Q(mpz_t output_number_Q,mpz_t* number_CRT,int num_primes, mpz_t *coeffs,mpz_t Q){
  int i;
  mpz_set_ui(output_number_Q,0);
  mpz_t aux;
  mpz_init(aux);
  for(i=0;i<num_primes;i++){
    mpz_mul(aux,coeffs[i],number_CRT[i]);
    mpz_add(output_number_Q,output_number_Q,aux);
  }

  mpz_mmod(output_number_Q,output_number_Q,Q);
}

void from_Q_to_CRT(mpz_t* output_number_CRT,mpz_t number_Q,int num_primes,mpz_t *P){

  int i=0;
  for(i=0;i<num_primes;i++){
    mpz_mmod(output_number_CRT[i],number_Q,P[i]);
  }
}

void from_Q_to_CRT_parallel(mpz_t* output_number_CRT,mpz_t number_Q,int num_primes,mpz_t *P){

  int i=0;
  #pragma omp parallel for
  for(i=0;i<num_primes;i++){
    mpz_mmod(output_number_CRT[i],number_Q,P[i]);
  }
}

void from_CRT_to_Q_int64(mpz_t output_number_Q,int64_t* number_CRT,int num_primes, mpz_t *coeffs,mpz_t Q){
  int i;
  mpz_set_ui(output_number_Q,0);
  mpz_t aux;
  mpz_init(aux);
  for(i=0;i<num_primes;i++){
    mpz_mul_ui(aux,coeffs[i],number_CRT[i]);
    mpz_add(output_number_Q,output_number_Q,aux);
  }

  mpz_mmod(output_number_Q,output_number_Q,Q);
}

void from_Q_to_CRT_int64(int64_t* output_number_CRT,mpz_t number_Q,int num_primes,int64_t *P){

  int i=0;
  mpz_t _output_number_CRT[num_primes];

  for(i=0;i<num_primes;i++){
    mpz_init(_output_number_CRT[i]);
    mpz_mmod_ui(_output_number_CRT[i],number_Q,P[i]);
    output_number_CRT[i]=mpz2ull(_output_number_CRT[i]);
  }
}

void from_Q_to_CRT_int64_parallel(int64_t* output_number_CRT,mpz_t number_Q,int num_primes,int64_t *P){

  int i=0;
  mpz_t _output_number_CRT[num_primes];
  #pragma omp parallel for
  for(i=0;i<num_primes;i++){
    mpz_init(_output_number_CRT[i]);
    mpz_mmod_ui(_output_number_CRT[i],number_Q,P[i]);
    output_number_CRT[i]=mpz2ull(_output_number_CRT[i]);
  }
}

void from_CRT_to_Q_int64_parallel(mpz_t output_number_Q,int64_t* number_CRT,int num_primes, mpz_t *coeffs,mpz_t Q){

  int i;
  mpz_set_ui(output_number_Q,0);
  //mpz_t aux;
  mpz_t aux[num_primes];

  initialize(aux,num_primes);

  #pragma omp parallel for
  for(i=0;i<num_primes;i++){
    mpz_mul_ui(aux[i],coeffs[i],number_CRT[i]);
  }

  mpz_set(output_number_Q,aux[0]);
  for(i=1;i<num_primes;i++){
    mpz_add(output_number_Q,output_number_Q,aux[i]);
  }

  mpz_mmod(output_number_Q,output_number_Q,Q);
}

