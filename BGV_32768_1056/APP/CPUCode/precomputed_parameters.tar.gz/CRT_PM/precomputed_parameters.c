 /*Calculates the precomputed parameters neded either for FPGA or C code
   of our FFT for the specified amount of handy_primes (CRT), and store them
   in the data/ subdirectory.
  If you want the data to work with FPGA, search and uncomment the lines
  If you want the algorithm to work for FPGA project, then set:
  #define FPGA 1
  otherwise, if you want it to work under the C project define FPGA as 0

The algorithm finds a suitable handy_prime between p_min_bitsize and p_max_bitsize, if possible.
  If a P is desired to be set, it must be set at the beginning of main(),
  along with a generator over the finite multiplicative field Z_p
  The algorithm also prints important info into the standard output.

  Must be compiled in c99 mode with -lm and -lgmp libraries
*/

#include <stdint.h>
#include <math.h>
#include <stdio.h>
#include <time.h>
#include <sys/time.h>
#include <inttypes.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <gmp.h>
#include <unistd.h>

#include "extended_euclidean_algorithm.h"
#include "bijection_CRT_Q.h"
#include "gmp_extra_functions.h"

void find_P_gen(mpz_t P,mpz_t handy_prime,mpz_t gen,mpz_t current, mpz_t stop);
void write_matrix(mpz_t **data, long long int outerlength,long long int innerlength,const  char * name);
void write_array(mpz_t *data, long long length,const  char * name);
void write_array_int64(int64_t *data, long long length,const  char * name);

#define N 16384
#define n 14
#define m 2*N //totient(m)=N
#define FPGA 0 //if FPGA==1 -> FPGA, else not FPGA
#define final_bitsize 1024
#define pi_min_bitsize 511
#define pi_max_bitsize pi_min_bitsize+1

void printArray(mpz_t data[], long long length, const char * name);
void printArray_int64_t(int64_t data[], long long length, const char * name);

/* void  compatibleFormatPrint(){ */
/*   //Wpowers and iWpowers already written (see method getWpowers[...]) */
/*   printArray(phiPowers_P,N,"data/phiPowers.dat"); */
/*     //printing iphiPowers: */
/*   printArray(iphiPowers_P,N,"data/iphiPowers.dat"); */
/*   if(FPGA) */
/*     printArray_int64_t(addresses,N/2,"data/bit_reversal_addresses.dat"); */
/* } */

void printArray_int64_t(int64_t data[], long long length,const  char * name){
  FILE *file = fopen(name,"w");
  long long i;
  for(i=0;i<length;i++){
    fprintf(file,"%lld ",(long long int)data[i]);
  }
 fclose(file);
}

void bit_reversal(int64_t x[], long long length){
    /* Do the bit reversal */
    long long i2 = length >> 1;
    int64_t tx;
    long long k;
    long long j = 0;
    long long i;
    for (i=0;i<length-1;i++) {
      if (i < j) {
	tx = x[i];
	x[i] = x[j];
	x[j] = tx;
      }
      k = i2;
      while (k <= j) {
	j -= k;
	k >>= 1;
      }
      j += k;
    }

  }
void bit_reversal_mpz(mpz_t x[], long long length){
    /* Do the bit reversal */
    long long i2 = length >> 1;
    mpz_t tx;
    mpz_init(tx);
    long long k;
    long long j = 0;
    long long i;
    for (i=0;i<length-1;i++) {
      if (i < j) {
	mpz_set(tx,x[i]);
	mpz_set(x[i],x[j]);
	mpz_set(x[j],tx);
      }
      k = i2;
      while (k <= j) {
	j -= k;
	k >>= 1;
      }
      j += k;
    }

  }

void find_inverse(mpz_t inverse,mpz_t number, mpz_t P){

  mpz_t aux;
  mpz_init(aux);
  if(mpz_extended_euclidean_algorithm(number,P,inverse,aux)!=1){
    fprintf(stderr,"ERROR: P=%s is not prime (can't find inverse of %s modulus P\n",
	    mpz_get_str(NULL,10,P),mpz_get_str(NULL,10,number));
    exit(1);
  }
  mpz_mod(inverse,inverse,P);//in order to remove the most likely negative value
}

void find_generator(mpz_t P,mpz_t handy_prime,mpz_t gen){//P==mm*handy_prime

  mpz_t subgen1,subgen2;
  mpz_t number;
  long long not_found=0;
  mpz_t pow_1,pow_2;
  mpz_init_set_ui(pow_1,N);
  mpz_mul(pow_1,pow_1,handy_prime);
  gmp_randstate_t state;
  gmp_randinit_default(state);
  mpz_init(subgen1);
  mpz_init(number);
  long long stop_condition=0;
  //
  while(stop_condition==0){
    mpz_urandomm(subgen1,state,P);
    mpz_powm(number,subgen1,pow_1,P);
    stop_condition = mpz_cmp_ui(number,1);
  }

  //free(pow_1);
  mpz_powm(subgen1,subgen1,handy_prime,P);
  mpz_init_set_ui(pow_2,m);
  stop_condition=0;
  mpz_init(subgen2);

  while(stop_condition==0){
    mpz_urandomm(subgen2,state,P);
    mpz_powm(subgen2,subgen2,pow_2,P);
    stop_condition = mpz_cmp_ui(subgen2,1);
  }

  //free(pow_2);
  mpz_mul(gen,subgen1,subgen2);
  mpz_mod(gen,gen,P);
  char *s4 = mpz_get_str(0,10,gen);
  printf("found generator of the field: %s\n",s4);

}
void rest_values(mpz_t P,mpz_t handy_prime,mpz_t gen,mpz_t phi,mpz_t W,mpz_t iphi,mpz_t iW){
  mpz_t aux;
  mpz_init(aux);
  mpz_init(phi);
  mpz_powm(phi,gen,handy_prime,P);// found phi
  mpz_init_set(W,phi);
  mpz_mul(W,W,W);
  mpz_mod(W,W,P);
  mpz_init(iphi);
  mpz_init(iW);
  mpz_set(iphi,phi);
  mpz_set_ui(aux,m-1);
  mpz_powm(iphi,iphi,aux,P);
  mpz_mul(iW,iphi,iphi);
  mpz_mod(iW,iW,P);
  char *s = mpz_get_str(0, 10, P); // get a in base 10
  char *s2 = mpz_get_str(0,2,P);
  int len = mpz_sizeinbase(P, 2);
  printf("P = %s = %s\n number of bits: %d\n",s,s2,len);
  s=mpz_get_str(0,10,phi);
  mpz_set_ui(aux,m);
  printf("phi = %s\n",s);
  printf("found phi and W for base \n, also   iphi and iW\n");

}
void find_P_gen_bit(mpz_t P,mpz_t handy_prime,mpz_t gen,int p_min_bitsize,int p_max_bitsize){
  //finds a handy_prime and a generator
  mpz_t current,stop;

  mpz_init_set_ui(current,2);
  mpz_pow_ui(current,current,p_min_bitsize);
  mpz_set(handy_prime,current);
  mpz_set_ui(current,m);
  mpz_div(handy_prime,handy_prime,current);
  mpz_mul(current,current,handy_prime);
  mpz_init_set_ui(stop,2);
  mpz_pow_ui(stop,stop,p_max_bitsize);
  char *s = mpz_get_str(NULL,2,current);
  find_P_gen(P,handy_prime,gen,current,stop);
}

void bits_modulus_parameters(mpz_t P,mpz_t P_minus_bit,int64_t* bitsize_P,int64_t* bitsize_P_minus_bit){
  (*bitsize_P) = mpz_sizeinbase(P, 2);
  mpz_init_set_ui(P_minus_bit,2);
  mpz_pow_ui(P_minus_bit,P_minus_bit,(*bitsize_P)-1);
  mpz_sub(P_minus_bit,P,P_minus_bit);
  char *s = mpz_get_str(0, 10, P_minus_bit);
  (*bitsize_P_minus_bit) = mpz_sizeinbase(P_minus_bit, 2);
  printf("P_minus_bit = %s \n number of bits: %lld\n",s,(long long int)(*bitsize_P_minus_bit));
}

void find_P_gen(mpz_t P,mpz_t handy_prime,mpz_t gen,mpz_t _current, mpz_t _stop){
  printf("trying to get a generator and valid prime...\n");
  char *s = mpz_get_str(NULL,10,handy_prime);
  /* printf("handy handy_prime initial: %s",s); */
  /* s = mpz_get_str(NULL,10,P); */
  /* printf("handy_prime initial: %s",s); */
  mpz_t current,stop;
  mpz_init_set(current,_current);
  mpz_init_set(stop,_stop);

  long long not_found=0;
  mpz_add_ui(current,current,1);
  not_found=mpz_probab_prime_p(current,25);
  char *s3;
  long long stop_condition=-1;
  while(stop_condition<0 && not_found==0){
    mpz_nextprime(handy_prime,handy_prime);
    mpz_set_ui(current,m);
    mpz_mul(current,current,handy_prime);
    mpz_add_ui(current,current,1);
    not_found=mpz_probab_prime_p(current,1000);
    stop_condition = mpz_cmp(current,stop);
  }
  s3=mpz_get_str(0,10,handy_prime);
  printf("handy_prime = %s\n",s3);
  if(stop_condition>=0){
    printf("error, there is no handy_prime with such conditions\n");
    exit(-1);
  }else if(not_found==1){
    mpz_set(P,current);
  }else{
    mpz_set(P,current);
    printf("ATTENTION: note that P has been checked only as probably handy_prime\n");
  }
  //free(stop);
  //determinedphiOrW_P=1;
  //once we have our p being p=q*2^n+1, being q a known handy_prime, and also n known, we can find a generator gen
  find_generator(current,handy_prime,gen);
  //rest_values();
}
void  get_W_values_iW_values(mpz_t base,mpz_t W,mpz_t iW, mpz_t **W_values, mpz_t **iW_values){
  long long i;
  mpz_t Wpowers[N/2], iWpowers[N/2];
  mpz_init_set_ui(Wpowers[0],1);
  mpz_init_set_ui(iWpowers[0],1);
  for(i=1;i<N/2;i++){
    mpz_init(Wpowers[i]);
    mpz_mul(Wpowers[i],Wpowers[i-1],W);
    mpz_mod(Wpowers[i],Wpowers[i],base);

    mpz_init(iWpowers[i]);
    mpz_mul(iWpowers[i],iWpowers[i-1],iW);
    mpz_mod(iWpowers[i],iWpowers[i],base);
  }

  long long Pij;
  long long j;

  mpz_t two,mpz_j,current;
  mpz_init_set_ui(two,2);
  mpz_init(mpz_j);
  mpz_init(current);
  for(i=0;i<n;i++){
    for(j=0;j<N/2;j++){
      mpz_set_ui(mpz_j,j);
      mpz_pow_ui(current,two,n-1-i);
      mpz_div(mpz_j,mpz_j,current);
      mpz_mul(current,mpz_j,current);
      Pij=mpz_get_ui(current);
      mpz_set(W_values[i][j],Wpowers[Pij]);
    }
  }


  for(i=0;i<n;i++){
    for(j=0;j<N/2;j++){
      mpz_set_ui(mpz_j,j);
      mpz_pow_ui(current,two,n-1-i);
      mpz_div(mpz_j,mpz_j,current);
      mpz_mul(current,mpz_j,current);
      Pij=mpz_get_ui(current);
      mpz_set(iW_values[i][j],iWpowers[Pij]);
    }
  }

}
void get_phi_powers_iphi_powers(mpz_t P,mpz_t phi,mpz_t iphi,mpz_t *phi_powers,mpz_t *iphi_powers){
  long long i;
  mpz_set_ui(phi_powers[0],1);
  mpz_set_ui(iphi_powers[0],1);
  for(i=1;i<N;i++){
    //mpz_init(phi_powers[i]);
    mpz_mul(phi_powers[i],phi_powers[i-1],phi);
    mpz_mod(phi_powers[i],phi_powers[i],P);
    //mpz_init(iphi_powers[i]);
    mpz_mul(iphi_powers[i],iphi_powers[i-1],iphi);
    mpz_mod(iphi_powers[i],iphi_powers[i],P);
  }
  if(FPGA)
   bit_reversal_mpz(phi_powers,N);
}
long long* get_bit_reversal_addresses(long long int* addresses,long long length){
  long long i;
  for(i=0;i<length;i++){
    addresses[i]=i;
  }

  bit_reversal((int64_t*) addresses,length);
  return addresses;
}
void printArray(mpz_t data[], long long length,const  char * name){
  FILE *file = fopen(name,"w");
  if(file==NULL){
    fprintf(stderr,"could not open file, have you created directory data?\n");
    exit(-1);}
  long long i;
  for(i=0;i<length;i++){
    fprintf(file,"%s ",mpz_get_str(0, 16, data[i]));
  }
  fclose(file);
}


mpz_t Wpowers_P[N/2];
mpz_t iWpowers_P[N/2];
mpz_t phiPowers_P[N];
mpz_t iphiPowers_P[N];
int64_t addresses[N/2];
mpz_t WPowersStages_P[n][N/2];
mpz_t iWPowersStages_P[n][N/2];
int64_t bit_reversal_addresses;

mpz_t phi_P;
mpz_t  W_P;
mpz_t iphi_P;
mpz_t iW_P;
mpz_t Wpowers_Q[N/2];
mpz_t iWpowers_Q[N/2];
mpz_t phiPowers_Q[N];
mpz_t iphiPowers_Q[N];
mpz_t WPowersStages_Q[n][N/2];
mpz_t iWPowersStages_Q[n][N/2];
mpz_t phi_Q;
mpz_t  W_Q;
mpz_t iphi_Q;
mpz_t iW_Q;

int number_of_primes(int min_final_bitsize){
  //we are going to have handy_primes of bitsize between 41 and 63, so we can establish an upperbound
  return (int)ceil(((float)min_final_bitsize)/((float)pi_max_bitsize));
}

void  export_precomputed_parameters(int64_t num_primes,mpz_t P[num_primes],
				    mpz_t handy_prime[num_primes],
				    mpz_t gen[num_primes],mpz_t **phi_powers,
				    mpz_t **iphi_powers,
				    mpz_t ***W_values,
				    mpz_t ***iW_values,
				    mpz_t iN[num_primes]){
  int i,j,k;
  FILE* file;

  //print primes
  write_array(P,num_primes,"data/primes.dat");
  //print Q
  mpz_t Q;
  mpz_init_set_ui(Q,1);
  for(i=0;i<num_primes;i++){
    mpz_mul(Q,P[i],Q);
  }
  write_array(&Q,1,"data/Q.dat");
  write_array(handy_prime,num_primes,"data/handy_primes.dat");

  //print inverses of N%P[i]
  write_array(iN,num_primes,"data/iN.dat");

  char *dir= malloc(sizeof("data/data_/"));
  char *filename = malloc(sizeof("data/data_/filenameverylong.dat"));
  //print rest of the values in subdirectories
  for(i=0;i<num_primes;i++){
    strcpy(dir,"data/data");
    char i_str[2];
    sprintf(i_str, "%i", i);
    strcat(dir,i_str);
    strcat(dir,"/");
    mkdir(dir,00774);


    //printing phi_powers
    strcpy(filename,dir);
    strcat(filename,"phi_powers.dat");
    write_array(phi_powers[i],N,filename);

    //printing iphi_powers
    strcpy(filename,dir);
    strcat(filename,"iphi_powers.dat");
    write_array(iphi_powers[i],N,filename);

    //printing W_values
    strcpy(filename,dir);
    strcat(filename,"W_values.dat");
    write_matrix(W_values[i],n,N/2,filename);

    //printing iW_values
    strcpy(filename,dir);
    strcat(filename,"iW_values.dat");
    write_matrix(iW_values[i],n,N/2,filename);
  }
}

void final_check_roots_unity(mpz_t P,mpz_t phi,mpz_t iphi,mpz_t W,mpz_t iW){
  long long j;
  mpz_t test;
  mpz_init_set(test,phi);
  for(j=1;j<m-1;j++){
    mpz_mul(test,phi,test);
    mpz_mod(test,test,P);
    if(mpz_cmp_ui(test,1)==0){
      printf("ATTENTION: tester has detected that phi is not a primitive mth root of unity\n");
      printf("problem in: %lld\n",j);
      exit(80);
    }
  }
  if(mpz_cmp(test,iphi)!=0){
    printf("ATTENTION: tester has detected that phi is not a primitive mth root of unity");
    char *s = mpz_get_str(NULL,10,test);
    char *s2 = mpz_get_str(NULL,10,iphi);
    printf("problem in the end :\n test: %s ; \n iphi : %s",s,s2);
    exit(80);
  }
  mpz_set(test,W);
  for(j=1;j<N-1;j++){
    mpz_mul(test,W,test);
    mpz_mod(test,test,P);
    if(mpz_cmp_ui(test,1)==0){
      printf("ATTENTION: tester has detected that W is not a primitive Nth root of unity\n");
      printf("problem in: %lld\n",j);
      exit(80);
    }
  }
  if(mpz_cmp(test,iW)!=0){
    printf("ATTENTION: tester has detected that W is not a primitive Nth root of unity");
    char *s = mpz_get_str(NULL,10,test);
    char *s2 = mpz_get_str(NULL,10,iW);
    printf("problem in the end :\n test: %s ; \n iW : %s",s,s2);
    exit(80);
  }

  printf("tester for roots of unity for prime:%s -> OK\n",mpz_get_str(NULL,10,P));
}

void test_with_value(mpz_t P[],mpz_t coeffs[],int64_t num_primes){
  mpz_t Q;
  mpz_init_set_ui(Q,1);
  int i;

  for(i=0;i<num_primes;i++){
    mpz_mul(Q,Q,P[i]);
  }
  mpz_t value;
  mpz_init_set(value,Q);
  mpz_sub_ui(value,value,1);
  mpz_t modulus[num_primes];
  initialize(modulus,num_primes);
  mpz_t result;
  mpz_init_set_ui(result,0);


  /* for(i=0;i<num_primes;i++){ */
  /*   mpz_mod(modulus[i],value,P[i]); */
  /* } */

  /* for(i=0;i<num_primes;i++){ */
  /*   mpz_mul(modulus[i],modulus[i],coeffs[i]); */
  /*   mpz_add(result,result,modulus[i]); */
  /* } */

  /* mpz_mod(result,result,Q); */
  from_Q_to_CRT(modulus,value,num_primes,P);
  from_CRT_to_Q(result,modulus,num_primes,coeffs,Q);


  if(mpz_cmp(result,value)==0){
    printf("tester for euclidean values (and CRT): -> OK\n");
  }else{
    printf("ATTENTION: tester for euclidean values not OK: either primes are not co-prime or the coeffs are not ok\n");
    exit(1);
  }
}

int main(){
  mkdir("data",00774);
  mpz_t mpz_N;
  mpz_init_set_ui(mpz_N,N);
  int64_t num_primes=number_of_primes(final_bitsize);
  int64_t first_bitsize=(final_bitsize-(num_primes-1)*(pi_min_bitsize+1));
  int first_min_bitsize=32;
  if(first_bitsize>0&&first_bitsize<first_min_bitsize)
    first_bitsize=first_min_bitsize;
  int64_t nN[2];
  nN[0]=n;
  nN[1]=N;
  long long int i;
  //write N and n
  write_array_int64(nN,2,"data/n_N.dat");
  //print number of primes
  write_array_int64((int64_t*)&num_primes,1,"data/num_primes.dat");

  //initialize variables...
  mpz_t P[num_primes],
    handy_prime[num_primes],
    gen[num_primes],
    phi[num_primes],
    iN[num_primes]
    ,W[num_primes]
    ,iphi[num_primes]
    ,iW[num_primes]
    ,P_minus_bit[num_primes];

  int64_t bitsize_P[num_primes];
  int64_t bitsize_P_minus_bit[num_primes];

  mpz_t **phi_powers= malloc(sizeof(mpz_t*)*num_primes);
  mpz_t **iphi_powers = malloc(sizeof(mpz_t*)*num_primes);
  mpz_t ***W_values=malloc(sizeof(mpz_t**)*num_primes);
  mpz_t ***iW_values=malloc(sizeof(mpz_t**)*num_primes);
  for(i=0;i<num_primes;i++){
    W_values[i]=malloc(sizeof(mpz_t*)*n);
    iW_values[i]=malloc(sizeof(mpz_t*)*n);
    phi_powers[i]=malloc(sizeof(mpz_t)*N);
    iphi_powers[i]=malloc(sizeof(mpz_t)*N);
    long long int j;
    for(j=0;j<n;j++){
      W_values[i][j]=malloc(sizeof(mpz_t)*N/2);
      iW_values[i][j]=malloc(sizeof(mpz_t)*N/2);
    }
  }

  initialize(P_minus_bit,num_primes);
  
  //value when to stop because there are not primes with the input conditions (maximum bit_size);
  mpz_t stop;
  mpz_init_set_ui(stop,2);
  mpz_pow_ui(stop,stop,pi_max_bitsize);

  printf("number of handy_primes generated for a minimum final bitsize of %i => %lld\n\n",final_bitsize,num_primes);

  //Now that we have the precomputed values
  //for FFTs, we need the values for
  //the bijection CRTrep <--> Zq being q=p[0]*...*p[num_primes-1]

  //printing data
  for(i=0;i<num_primes;i++){
    printf("prime number:%lld\n",i);

    //initialize data (mpz_init)
    mpz_init_set_ui(P[i],0);
    mpz_init_set_ui(handy_prime[i],0);
    mpz_init_set_ui(gen[i],0);
    mpz_init(phi[i]);mpz_init(iphi[i]);mpz_init(W[i]);mpz_init(iW[i]);
    mpz_init(iN[i]);

    initialize(phi_powers[i],N);
    initialize(iphi_powers[i],N);
    initialize_matrix(W_values[i],n,N/2);
    initialize_matrix(iW_values[i],n,N/2);
    //find_generator
    
    if(i==0){
      if(first_bitsize>0&&first_bitsize<(pi_min_bitsize+1))
	find_P_gen_bit(P[i],handy_prime[i],gen[i],first_bitsize-1,pi_max_bitsize);
      else
	find_P_gen_bit(P[i],handy_prime[i],gen[i],pi_min_bitsize,pi_max_bitsize);
    }else if(i==1){
      if(first_bitsize>0&&first_bitsize<(pi_min_bitsize+1))
	find_P_gen_bit(P[i],handy_prime[i],gen[i],pi_min_bitsize,pi_max_bitsize);
      else{
	mpz_set(handy_prime[i],handy_prime[i-1]);
	find_P_gen(P[i],handy_prime[i],gen[i],P[i-1],stop);
      }
    }
    else{
      mpz_set(handy_prime[i],handy_prime[i-1]);
      find_P_gen(P[i],handy_prime[i],gen[i],P[i-1],stop);
    }
    bits_modulus_parameters(P[i],P_minus_bit[i],&bitsize_P[i],&bitsize_P_minus_bit[i]);
    rest_values(P[i],handy_prime[i],gen[i],phi[i],W[i],iphi[i],iW[i]);
    printf("getting W_values...\n");
    get_W_values_iW_values(P[i],W[i],iW[i],W_values[i], iW_values[i]);

    printf("getting Phi_values...\n");
    get_phi_powers_iphi_powers(P[i],phi[i],iphi[i],phi_powers[i],iphi_powers[i]);

    //find inverse of N (iN)
    printf("finding iN... \n");
    find_inverse(iN[i],mpz_N,P[i]);

    printf("finished prime number:%lld\n\n",i);
  }
  mpz_get_str(NULL,16,phi_powers[0][0]);

  //VALUES FOR BIJECTION (coefficients from extended euclidean)
  mpz_t Q;
  mpz_init_set_ui(Q,1);
  for(i=0;i<num_primes;i++){
    mpz_mul(Q,Q,P[i]);
  }

  mpz_t coeffs_euclidean[num_primes];
  initialize(coeffs_euclidean,num_primes);
  mpz_t aux,aux2;
  mpz_init(aux);
  mpz_init(aux2);
  for(i=0;i<num_primes;i++){
    mpz_div(aux,Q,P[i]);
    int d;
    if((d=mpz_extended_euclidean_algorithm(aux,P[i],coeffs_euclidean[i],aux2))!=1){
      fprintf(stderr,"ERROR: gcd(P[%lld],Q/P[%lld])=%i!=1\n",i,i,d);
      fprintf(stderr,"ERROR: value of P[%lld]=%s\n",i,mpz_get_str(NULL,10,P[i]));
      fprintf(stderr,"ERROR: value of Q/P[%lld]=%s\n",i,mpz_get_str(NULL,10,aux));
      exit(1);
    }else{
      mpz_mul(coeffs_euclidean[i],coeffs_euclidean[i],aux);
    }
  }
  //BEFORE PRINTING --> TEST DATA

  for(i=0;i<num_primes;i++){
    final_check_roots_unity(P[i],phi[i],iphi[i],W[i],iW[i]);
  }

  test_with_value(P,coeffs_euclidean,num_primes);

  //export data specific for FFT
  export_precomputed_parameters(num_primes,P,handy_prime,gen,phi_powers,iphi_powers,W_values,iW_values,iN);

  //export data for bits_modulus
  write_array(P_minus_bit,num_primes,"data/primes_minus_bit.dat");
  write_array_int64(bitsize_P,num_primes,"data/bitsize_primes.dat");
  write_array_int64(bitsize_P_minus_bit,num_primes,"data/bitsize_primes_minus_bit.dat");
  //export bit reversal addresses (only FPGA)
  //ATTENTION, bit reversal addresses are written in decimal base
  if(FPGA){
    long long int addresses[N/2];
    get_bit_reversal_addresses(addresses,N/2);
    write_array_int64((int64_t*)addresses,N/2,"data/bit_reversal_addresses.dat");
  }

  //export data for bijection
  //print coefficients extended euclidean algorithm
  write_array(coeffs_euclidean,num_primes,"data/coefficients_extended_euclidean.dat");

  printf("FINISHED\n");

  exit(0);

}

void write_array(mpz_t *data, long long length,const  char * name){
  FILE *file = fopen(name,"w");
  if(file==NULL){
    fprintf(stderr,"could not open file %s\n",name);
    exit(-1);}
  long long i;
  for(i=0;i<length;i++){
    fprintf(file,"%s ",mpz_get_str(NULL, 16, data[i]));
  }
  fclose(file);
}

void write_matrix(mpz_t **data, long long int outerlength,long long int innerlength,const  char * name){
  FILE *file = fopen(name,"w");
  if(file==NULL){
    fprintf(stderr,"could not open file %s\n",name);
    exit(-1);}
  long long int i,j;
  for(i=0;i<outerlength;i++){
    for(j=0;j<innerlength;j++){
      fprintf(file,"%s ",mpz_get_str(NULL, 16, data[i][j]));
    }
  }
  fclose(file);
}

void write_array_int64(int64_t *data, long long length,const  char * name){
  FILE *file = fopen(name,"w");
  if(file==NULL){
    fprintf(stderr,"could not open file %s\n",name);
    exit(-1);}
  long long i;
  for(i=0;i<length;i++){
    fprintf(file,"%lli ",(long long int)data[i]);
  }
  fclose(file);
}
